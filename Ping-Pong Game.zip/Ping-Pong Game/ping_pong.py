from pygame import *
class GameSprite(sprite.Sprite):
    def __init__(self,player_image,player_X,player_y,player_speed,width,height):
        self.image = transform.scale(image.load(player_image),(width,height))
        self.speed = player_speed
        self.rect = self.image.get_rect()
        self.rect.x = player_X
        self.rect.y = player_y

    def reset(self):
        window.blit((self.image),(self.rect.x,self.rect.y))

class Player(GameSprite):
    def update_r(self):
        keys = key.get_pressed()
        if keys[K_UP] and self.rect.y > 5:
            self.rect.y -= self.speed
        if keys[K_DOWN] and self.rect.y < win_height-80:
            self.rect.y += self.speed
    
    def update_l(self):
            keys = key.get_pressed()
            if keys[K_w] and self.rect.y > 5:
                self.rect.y -= self.speed
            if keys[K_s] and self.rect.y < win_height-80:
                self.rect.y += self.speed

bg_color = (200,255,255)
win_width = 600
win_height = 500
window = display.set_mode((win_width,win_height))
window.fill(bg_color)

game = True
end = False
clock = time.Clock()
FPS = 60

racket1 = Player('racket.png',30,200,4,50,150)
racket2 = Player('racket.png',520,200,4,50,150)
ball = Player('ball.png',200,200,4,50,50)

font.init()
font = font.Font(None,35)
win1 = font.render('PLAYER 1 WIN!!!',True,(0,128,0))
win2 = font.render('PLAYER 2 WIN!!!',True,(0,128,0))

speed_x = 3
speed_y = 3

while game:
    for e in event.get():
        if e.type == QUIT:
            game = False
        if end != True:
            window.fill(bg_color)
            racket1.update_l()
            racket2.update_r()
            ball.rect.x += speed_x
            ball.rect.y += speed_y

            if sprite.collide_rect(racket1,ball) or sprite.collide_rect(racket2,ball):
                speed_x *= -1
                speed_y *= -1

            if ball.rect.y > win_height-50 or ball.rect.y < 0:
                speed_y *= -1

            if ball.rect.x < 0:
                end = True
                window.blit(win2,(200,200))
                game = False
                racket1.reset()
                racket2.reset()
                ball.reset()
            
            if ball.rect.x > win_width:
                end = True
                window.blit(win1,(200,200))
                game = False
                racket1.reset()
                racket2.reset()
                ball.reset()

display.update()
clock.tick(FPS)